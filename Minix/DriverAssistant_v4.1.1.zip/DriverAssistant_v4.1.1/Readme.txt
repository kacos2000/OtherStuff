瑞芯微驱动安装助手
支持Rockusb驱动和Rockchip Adb驱动预安装和卸载
支持xp,win7_32,win7_64,win8_32,win8_64操作系统
目录说明：
工具目录\Driver:Rockusb驱动目录
工具目录\ADBDriver:Rockchip ADB驱动目录

注意事项：
为了所有设备都使用更新的驱动，请先“卸载”再进行“安装”
xp系统当通过工具安装驱动完成,连接Rockchip ADB设备时还会提示你发现新设备，安装驱动时选择"自动安装",即可成功完成驱动安装。
